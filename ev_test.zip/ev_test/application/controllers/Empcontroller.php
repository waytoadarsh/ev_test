<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Empcontroller extends CI_Controller {

	public function __construct() {

		parent::__construct();
		$this->load->model('Emp_model','emodel');
	}

	public function index()
	{
		$this->load->view('emp/employees_form');
	}
	public function insert_emp()
	{
		$this->form_validation->set_rules('efname','Employees First Name','trim|required');
		$this->form_validation->set_rules('elname','Employees Last Name','trim|required');
		$this->form_validation->set_rules('ecname','Employees Company Name','trim|required');
		$this->form_validation->set_rules('email','Employees Email','trim|required|valid_email');
		$this->form_validation->set_rules('ephone','Employees Phone','required');
		if ($this->form_validation->run() == false) {

			$this->load->view('emp/employees_form');

       		 }
       	else{
			$data = array(
			'firstname' => $this->input->post("efname"),
			'lastname' => $this->input->post("elname"),
			'company' => $this->input->post("ecname"),
			'email' => $this->input->post("email"),
			'phone' => $this->input->post("ephone"),
			'status' => 'active'
			 );
	   		 if($res=$this->emodel->insert_Edata($data))
	   		 {
	   		  $data_msg['success_msg']="Employees details added successfully";
	   		  $this->load->view('emp/employees_form',$data_msg);
			 }
			 else
			 {
			 	
			   $data_msg['error_msg']="Faild to add";
			   $this->load->view('emp/employees_form',$data_msg);
			 }
	       		
	       	}
        	 
	}
	public function list_emp(){

		$data['emp_list'] = $this->emodel->list_all_emp();
		$this->load->view('emp/list_employees',$data);
	}
	public function edit_emp($empid){
		$emp_data=$this->emodel->get_Edata($empid);
		$data = array();
		$data['emp']=$emp_data;
		$this->load->view('emp/list_edit_employess',$data);

	}

}
