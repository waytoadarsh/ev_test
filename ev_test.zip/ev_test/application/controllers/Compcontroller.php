<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Compcontroller extends CI_Controller {

	public function __construct() {

		parent::__construct();
		$this->load->model('Comp_model','cmodel');
	}

	public function index()
	{
		$this->load->view('comp/companies_form');
	}
	public function insert_comp()
	{
		$this->form_validation->set_rules('cname','Companies Name','trim|required');
		$this->form_validation->set_rules('cemail','Comapnies Email','trim|required|valid_email|xss_clean');
		$this->form_validation->set_rules('cweb','Comapnies Website','trim|required');
		if (empty($_FILES['cimage']['name']))
		{
		    $this->form_validation->set_rules('cimage', 'Comapnies Logo', 'required');
		}
		$config = array(
				'upload_path' => "uploads/",
				'allowed_types' => "jpg|png|jpeg",
				'overwrite' => TRUE,
				'max_size' => "2048000",
				// 'max_height' => "100",
				// 'max_width' => "100"
				);
		
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
        $this->upload->do_upload('cimage');
        $file_details = array('cimage_metadata' => $this->upload->data());
        $logo_name=$file_details['cimage_metadata']['file_name'];
        //print_r($logo_name);
        if ($this->form_validation->run() == FALSE) {

        	$this->load->view('comp/companies_form');
        }
        else{

        	 $data = array(
        		'logo' =>$logo_name,
        		'name' => $this->input->post("cname"),
        		'email' => $this->input->post("cemail"),
        		'website' => $this->input->post("cweb"),
       		 );
	       	$res=$this->cmodel->insert_Cdata($data);
	       		 if($res)
	       		 {

	       		  $data['success_msg']="Company details added successfully";
	       		  $this->load->view('comp/companies_form',$data);
				 }else
				 {
				 	
				   $data['error_msg']="Faild to add";
				   $this->load->view('comp/companies_form',$data);
				 }
       		 }


	}
	public function list_comp(){

		$data['comp_list'] = $this->cmodel->list_all_comp();
		$this->load->view('comp/list_copmanies',$data);

	}
	public function edit_comp($c_id = NULL){

		$data['comp_up_list'] = $this->cmodel->list_up_comp($c_id);
		$this->load->view('comp/list_up_companies',$data);

	}
	public function update_comp($c_id = NULL){
		$data = array(
        		'name' => $this->input->post("cname"),
        		'email' => $this->input->post("cemail"),
        		'website' => $this->input->post("cweb"),
       		 );

		$data['comp_up_list'] = $this->cmodel->up_comp($c_id);
		$this->load->view('comp/list_up_companies',$data);

	}
	public function delete_comp($comp_id = NULL){
		// echo $comp_id;
		// die();
		$this->cmodel->remove_comp($comp_id);
		//$this->load->view('comp/list_copmanies');



	}

}
