<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Emp_model extends CI_Model{

	public function insert_Edata($data){

		$this->db->insert('employees_db',$data);
	}
	public function get_Edata($empid){
		$this->db->where('id',$empid);
		return $employees= $this->db->get('employees_db')->row_array();
	}
	public function list_all_emp(){

		$this->db->select('*');
		$query = $this->db->get('employees_db');
		$result = $query->result_array();
		return $result;
	}

}