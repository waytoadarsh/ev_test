<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Comp_model extends CI_Model{


	public function insert_Cdata($data){

		$this->db->insert('companies_db',$data);
	}
	public function list_all_comp(){

		$this->db->select('*');
		$query = $this->db->get('companies_db');
		$result = $query->result_array();
		// echo "<pre>";
		// print_r($result);
		// die();
		return $result;
	}
	public function get_Cdata($cmpid){
		$this->db->where('id',$cmpid);
		return $compines= $this->db->get('companies_db')->row_array();
	}
	public function list_up_comp($c_id){
		$this->db->select('*');
		$this->db->where('id',$c_id);
		$query = $this->db->get('companies_db');
		$result = $query->result_array();
		// echo "<pre>";
		// print_r($result);
		// die();
		return $result;
				
	}

	public function up_comp($c_id,$data){

		$this->db->where('id',$c_id);
		$this->db->update('companies_db', $data);
		return $result;
	}
	public function remove_comp($comp_id){
		$data = array(
        'status' =>'remove'
		);

		$this->db->where('id',$comp_id);
		$this->db->update('companies_db', $data);
		redirect('compcontroller/list_comp', 'refresh');

	}




}