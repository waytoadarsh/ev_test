<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
      <div class="container-fluid px-4">
        <h1 class="mt-4 text-center">All Employees</h1>
        <a href="<?= base_url('empcontroller'); ?>"><button type="button"  class="btn btn-primary">Add New Employees</button></a>

        <table class="table table-hover" id="portfolio_table">
          <thead>
            <tr>
              <th scope="col">Employess First Name</th>
              <th scope="col">Employess Last Name</th>
              <th scope="col">Employess Company</th>
              <th scope="col">Employess Email</th>
              <th scope="col">Employess Phone Number</th>
              <th scope="col">Employess Status</th>
            </tr>
          </thead>
          <tbody>
          <?php
              if($emp_list){

                foreach($emp_list as $emp_data)
                {
                  $emp_id = $emp_data['id'];
                  if($emp_data['status'] == 'active'){
                    $class= 'table-success';
                  }
                  else
                    $class= 'table-warning';
                  ?>
                  <tr class='<?= $class; ?>'>
                    <td><?= $emp_data['firstname'];?></td>
                    <td><?= $emp_data['lastname'];?></td>
                    <td><?= $emp_data['company'];?></td>
                    <td><?= $emp_data['email'];?></td>
                    <td><?= $emp_data['phone'];?></td>
                    <td><?= $emp_data['status'];?></td>
                    <td>
                    <a href="edit_emp/<?= $emp_id;  ?>"><button type="button" id="edit-comp" class="btn btn-outline-success btn-sm">Edit</button></a>
                    <a href="delete_emp/<?= $emp_id;  ?>"><button type="button" id="delt-comp" class="btn btn-outline-danger btn-sm">Delete</button></a>
                    </td>
                  </tr>
              <?php
              }
            }
          ?>
        </tbody>
      </div>

</body>
</html>