<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div class="container">
  <div class="form-group" style="text-align: center;">
    <a href="<?= base_url('compcontroller'); ?>"><button type="submit" class="btn btn-info">COMPANIES</button></a>
    <a href="<?= base_url('empcontroller'); ?>"><button type="submit" class="btn btn-info">EMPLOYEES</button></a>
    <a href="<?= base_url('empcontroller/list_emp'); ?>"><button type="submit" class="btn btn-success" id="add">List all Employes</button></a>
  </div>
  <h2 style="text-align: center;">ADD NEW EMPLOYEES</h2>
        <?php echo form_open_multipart('Empcontroller/insert_emp');?>
    <div class="form-group">
      <label for="usr">Employess First Name:</label>
      <input type="text" class="form-control" id="cname" name="efname" placeholder="First Name">
      <?= form_error('efname', '<p class="text-danger">', '</p>'); ?>

      <label for="usr">Employees Last Name:</label>
      <input type="text" class="form-control" id="cname" name="elname" placeholder="Last Name">
      <?= form_error('elname', '<p class="text-danger">', '</p>'); ?>

      <label for="email">Employees Company:</label>
      <input type="text" class="form-control" id="ecname" name="ecname" placeholder="Employees Company">
      <?= form_error('ecname', '<p class="text-danger">', '</p>'); ?>

      <label for="email">Employees Email:</label>
      <input type="email" class="form-control" id="email" placeholder="Employees email" name="email">
      <?= form_error('email', '<p class="text-danger">', '</p>'); ?>

      <label for="usr">Employees Phone number:</label>
      <input type="text" class="form-control" id="ephone" name="ephone" placeholder="Employees Phone number">
      <?= form_error('ephone', '<p class="text-danger">', '</p>'); ?>
    </div>
     <button type="submit" class="btn btn-success" id="add">Add</button>
</form>
<?php if (isset($success_msg)) { ?>
      <div class="alert alert-success">
      <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
        <strong><?php echo $success_msg; ?></strong>
      </div>
<?php }else if(isset($error_msg)){?>
      <div class="alert alert-danger">
      <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
        <strong><?php echo $error_msg; ?></strong>
      </div>
<?php } ?>
</div>

</body>
</html>