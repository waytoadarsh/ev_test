<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div class="container">
  <div class="form-group" style="text-align: center;">
    <a href="<?= base_url('compcontroller'); ?>"><button type="submit" class="btn btn-info">COMPANIES</button></a>
    <a href="<?= base_url('empcontroller'); ?>"><button type="submit" class="btn btn-info">EMPLOYEES</button></a>
    <a href="<?= base_url('empcontroller/list_emp'); ?>"><button type="submit" class="btn btn-success" id="add">List all Employes</button></a>
  </div>
  <h2 style="text-align: center;">ADD NEW EMPLOYEES</h2>
        <?php echo form_open_multipart('Empcontroller/insert_emp');?>
    <div class="form-group">
      <label for="usr">Employess First Name:</label>
      <input type="text" class="form-control" id="cname" name="efname" value="<?php echo set_value('efname',$emp['firstname']);?>">
      <?= form_error('efname', '<p class="text-danger">', '</p>'); ?>

      <label for="usr">Employees Last Name:</label>
      <input type="text" class="form-control" id="cname" name="elname" value="<?php echo set_value('efname',$emp['lastname']);?>">
      <?= form_error('elname', '<p class="text-danger">', '</p>'); ?>

      <label for="email">Employees Company:</label>
      <input type="text" class="form-control" id="ecname" name="ecname" value="<?php echo set_value('efname',$emp['company']);?>">
      <?= form_error('ecname', '<p class="text-danger">', '</p>'); ?>

      <label for="email">Employees Email:</label>
      <input type="email" class="form-control" id="email" value="<?php echo set_value('efname',$emp['email']);?>">
      <?= form_error('email', '<p class="text-danger">', '</p>'); ?>

      <label for="usr">Employees Phone number:</label>
      <input type="text" class="form-control" id="ephone" value="<?php echo set_value('efname',$emp['phone']);?>">
      <?= form_error('ephone', '<p class="text-danger">', '</p>'); ?>
    </div>
     <button type="submit" class="btn btn-success" id="add">update</button>
</form>

</div>

</body>
</html>