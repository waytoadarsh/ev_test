<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div class="container">
  <div class="form-group" style="text-align: center;">
    <a href="<?= base_url('compcontroller'); ?>"><button type="submit" class="btn btn-info">COMPANIES</button></a>
    <a href="<?= base_url('empcontroller'); ?>"><button type="submit" class="btn btn-info">EMPLOYEES</button></a>
    <a href="<?= base_url('compcontroller/list_comp'); ?>"><button type="submit" class="btn btn-success" id="add">List all Companies</button></a>
  </div>
  <h2 style="text-align: center;">ADD NEW COMPANIES</h2>
    <?php echo form_open_multipart('compcontroller/insert_comp');?>
    <div class="form-group">
      <label for="usr">Companies Name:</label>
      <input type="text" class="form-control" id="cname" name="cname" placeholder="Companies Name">
      <?= form_error('cname', '<p class="text-danger">', '</p>'); ?>


      <label for="email">Companies Email:</label>
      <input type="email" class="form-control" id="cemail" placeholder="Comapnies email" name="cemail">
      <?= form_error('cemail', '<p class="text-danger">', '</p>'); ?>


      <label for="email">Companies Logo:</label>
      <input type="file" name="cimage" class="form-control-file" id="cimage">
      <?= form_error('cimage', '<p class="text-danger">', '</p>'); ?>


      <label for="email">Companies Website:</label>
      <input type="text" class="form-control" id="cemail" placeholder="Comapnies website" name="cweb">
      <?= form_error('cweb', '<p class="text-danger">', '</p>'); ?>


    </div>
     <button type="submit" class="btn btn-success" id="add">Add</button>

</form>
<?php if (isset($success_msg)) { ?>
      <div class="alert alert-success">
      <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
        <strong><?php echo $success_msg; ?></strong>
      </div>
<?php }else if(isset($error_msg)){?>
      <div class="alert alert-danger">
      <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
        <strong><?php echo $error_msg; ?></strong>
      </div>
<?php } ?>
</div>

</body>
</html>