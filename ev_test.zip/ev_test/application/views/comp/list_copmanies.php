<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
      <div class="container-fluid px-4">
        <h1 class="mt-4 text-center">All Companies</h1>
        <a href="<?= base_url('compcontroller'); ?>"><button type="button"  class="btn btn-primary">Add New Company</button></a>

        <table class="table table-hover" id="portfolio_table">
          <thead>
            <tr>
              <th scope="col">Companies Logo</th>
              <th scope="col">Companies Name</th>
              <th scope="col">Companies Email</th>
              <th scope="col">Companies Website</th>
              <th scope="col">Companies status</th>
            </tr>
          </thead>
          <tbody>
          <?php
              if($comp_list){

                foreach($comp_list as $comp_data)
                {
                  $comp_logo = $comp_data['logo'];
                  $comp_id = $comp_data['id'];
                  if($comp_data['status'] == 'active'){
                    $class= 'table-success';
                  }
                  else
                    $class= 'table-warning';
                  ?>
                  <tr class='<?= $class; ?>'>
                    <td><img class="img-fluid" width="135"  src="<?php echo base_url("uploads/$comp_logo");?>" alt="admin" /></td>
                    <td><?= $comp_data['name'];?></td>
                    <td><?= $comp_data['email'];?></td>
                    <td><?= $comp_data['website'];?></td>
                    <td><?= $comp_data['status'];?></td>
                    <td>
                    <a href="edit_comp/<?= $comp_id;  ?>"><button type="button" id="edit-comp" class="btn btn-outline-success btn-sm">Edit</button></a>
                    <a href="delete_comp/<?= $comp_id;  ?>"><button type="button" id="delt-comp" class="btn btn-outline-danger btn-sm">Delete</button></a>
                    </td>
                  </tr>
              <?php
              }
            }
          ?>
        </tbody>
      </div>

</body>
</html>